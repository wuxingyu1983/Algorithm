
/*
  CEOI 2006
  Competition Day #2
  Task CONNECT
  Output correctness checker
*/

#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>

using namespace std;

#define BUFSIZE      0x10000
char buff[BUFSIZE];

int n, m;
char a[25][82];
char b[25][82];

char *tiles[3][11] = {
   { "+ +", "+ +", "+.+", "+ +", "+ +", "+ +", "+.+", "+.+", "+.+", "+ +", "+ +" },
   { "   ", ".X ", " X ", " X.", " X ", "...", " . ", ".. ", " ..", " ..", ".. " },
   { "+ +", "+ +", "+ +", "+ +", "+.+", "+ +", "+.+", "+ +", "+ +", "+.+", "+.+" },
};
int cost[11] = { 0, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2 };

int main(int argc, char *argv[])
{
   if ( argc <= 3 ) {
      fprintf( stderr, "usage: check input-file official-output-file your-output-file\n" );
      return 2;
   }

   FILE
      *fin  = fopen(argv[1], "rt"),
      *foff = fopen(argv[2], "rt"),
      *fout = fopen(argv[3], "rt");

   fscanf( fin, "%d%d%*c", &n, &m );
   for( int r = 0; r < n; ++r )
      fgets( a[r], sizeof a[r], fin );

   int official;
   fscanf( foff, "%d", &official );

   int yours;
   if( fgets( buff, BUFSIZE, fout ) == 0 ) {
      fprintf( stderr, "No output\n" );
      return 1;
   }

   sscanf( buff, "%d", &yours );

   if( yours != official ) {
      printf( "Wrong score! (%d, expected %d)", yours, official );
      return 0;
   }

   for( int r = 0; r < n; ++r )
      if( fgets( b[r], sizeof b[r], fout ) == 0 ) {
         printf( "Partially correct (80%% score). Couldn't read board." );
         return 0;
      }

   for( int r = 0; r < n; ++r ) {
      for( int c = 0; c < m; ++c ) {
         if( r%2 == 0 && c%2 == 0 && b[r][c] != '+' ) {
            printf( "Partially correct (80%% score). Error parsing board." );
            return 0;
         }

         if( r%2 == 0 && c%2 == 1 && a[r][c] == ' ' )
            if( b[r][c] != ' ' && b[r][c] != '.' ) {
               printf( "Partially correct (80%% score). Error parsing board." );
               return 0;
            }
         if( r%2 == 0 && c%2 == 1 && a[r][c] == '|' )
            if( b[r][c] != '|' ) {
               printf( "Partially correct (80%% score). Error parsing board." );
               return 0;
            }

         if( r%2 == 1 && c%2 == 0 && a[r][c] == ' ' )
            if( b[r][c] != ' ' && b[r][c] != '.' ) {
               printf( "Partially correct (80%% score). Error parsing board." );
               return 0;
            }
         if( r%2 == 1 && c%2 == 0 && a[r][c] == '-' )
            if( b[r][c] != '-' ) {
               printf( "Partially correct (80%% score). Error parsing board." );
               return 0;
            }

         if( r%2 == 1 && c%2 == 1 && a[r][c] == ' ' )
            if( b[r][c] != ' ' && b[r][c] != '.' ) {
               printf( "Partially correct (80%% score). Error parsing board." );
               return 0;
            }
         if( r%2 == 1 && c%2 == 1 && a[r][c] == 'X' )
            if( b[r][c] != 'X' ) {
               printf( "Partially correct (80%% score). Error parsing board." );
               return 0;
            }
      }
   }

   int total = 0;

   for( int r = 0; r+2 < n; r += 2 ) {
      for( int c = 0; c+2 < m; c += 2 ) {
         int k;
         for( k = 0; k < 11; ++k ) {
            int ok = 1;
            for( int dr = 0; dr < 3; ++dr )
               for( int dc = 0; dc < 3; ++dc )
                  if( ( b[r+dr][c+dc] == '.' || tiles[dr][k][dc] == '.' ) && b[r+dr][c+dc] != tiles[dr][k][dc] )
                     ok = 0;
            if( ok ) {
               total += cost[k];
               break;
            }
         }
         if( k == 11 ) {
            printf( "Partially correct (80%% score). Illegal paths found." );
            return 0;
         }
      }
   }

   if( total != yours ) {
      printf( "Partially correct (80%% score). Actual score on board is wrong." );
      return 0;
   }

   printf( "Correct!\n" );

   return 0;
}
